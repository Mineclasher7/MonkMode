# MonkMode

## Project Overview

This is a chrome extension for boosting productivity when surfing the web. By the click of a button you can block distracting sites from your sight.

## Features

This project only checks your hyperlinks to block viewing certain websites on the blocked list.

## Installation

To use this extension in chrome, get started by downloading the MonkMode ZIP file on GitHub. Extract all files from the zip folder and navigate to chrome://extensions. Make sure developer mode is on, then press load unpacked. Finally select the MonkMode folder for the extension, and confirm. Now you will be able to block any website you want and clear your focus!
